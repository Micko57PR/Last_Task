import axios from "axios"
import { useState, useEffect } from "react"
// // import { Lightbox } from "react-modal-image";

// // // ...
// export default function Event(){
// //     // const [event, setEvent]

// //     const closeLightbox = () => {
// //         this.state.open = true;
// //     };
// // }
// // // ...

// // {
// //   this.state.open && (
// //     <Lightbox
// //     //   medium={urlToLargeImageFile}
// //     //   large={urlToHugeImageFile}
// //       alt="Hello World!"
// //       onClose={this.closeLightbox}
// //     />
// //   );
// // }

